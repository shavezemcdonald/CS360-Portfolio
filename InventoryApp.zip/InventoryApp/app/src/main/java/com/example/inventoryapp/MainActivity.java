package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private DatabaseHelper databaseHelper;
    private SharedPreferences smsSettings;
    private int currentScreen = 0;
    private boolean loggedIn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);
        smsSettings = getSharedPreferences("sms_settings", MODE_PRIVATE);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (currentScreen == 2) {
                    showInventoryScreen();
                } else if (currentScreen == 1) {
                    loggedIn = false;
                    showLoginScreen();
                } else {
                    finish();
                }
            }
        });

        showLoginScreen();
    }

    private void showLoginScreen() {
        currentScreen = 0;
        setContentView(R.layout.activity_main);

        EditText username = findViewById(R.id.editUsername);
        EditText password = findViewById(R.id.editPassword);

        findViewById(R.id.buttonCreateAccount).setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString();

            if (user.isEmpty() || pass.isEmpty()) {
                showMessage("Enter a username and password.");
                return;
            }

            if (databaseHelper.createUser(user, pass)) {
                showMessage("Account created. You can now log in.");
                username.setText("");
                password.setText("");
            } else {
                showMessage("That username already exists.");
            }
        });

        findViewById(R.id.buttonLogin).setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString();

            if (user.isEmpty() || pass.isEmpty()) {
                showMessage("Enter a username and password.");
                return;
            }

            if (databaseHelper.checkUser(user, pass)) {
                loggedIn = true;
                showInventoryScreen();
            } else {
                showMessage("Incorrect username or password.");
            }
        });
    }

    private void showInventoryScreen() {
        if (!loggedIn) {
            showLoginScreen();
            return;
        }

        currentScreen = 1;
        setContentView(R.layout.activity_inventory);

        findViewById(R.id.buttonAddItem).setOnClickListener(v -> showItemDialog(null));
        findViewById(R.id.buttonNotificationSettings).setOnClickListener(v -> showNotificationScreen());
        findViewById(R.id.buttonLogout).setOnClickListener(v -> {
            loggedIn = false;
            showLoginScreen();
        });

        LinearLayout rows = findViewById(R.id.inventoryRows);
        TextView emptyText = findViewById(R.id.textEmpty);
        TextView lowStockText = findViewById(R.id.textLowStock);

        List<InventoryItem> items = databaseHelper.getItems();
        emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        int lowStockCount = 0;

        for (InventoryItem item : items) {
            if (item.isLow()) {
                lowStockCount++;
            }

            View row = getLayoutInflater().inflate(R.layout.row_inventory, rows, false);

            ((TextView) row.findViewById(R.id.textItemName)).setText(item.name);
            ((TextView) row.findViewById(R.id.textItemQuantity)).setText(String.valueOf(item.quantity));
            ((TextView) row.findViewById(R.id.textItemThreshold)).setText(String.valueOf(item.threshold));
            row.findViewById(R.id.textItemLow).setVisibility(item.isLow() ? View.VISIBLE : View.GONE);

            row.findViewById(R.id.buttonEditItem).setOnClickListener(v -> showItemDialog(item));
            row.findViewById(R.id.buttonDeleteItem).setOnClickListener(v -> confirmDelete(item));

            rows.addView(row);
        }

        lowStockText.setText("Low-stock items: " + lowStockCount);
    }

    private void confirmDelete(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete item?")
                .setMessage("Delete " + item.name + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (databaseHelper.deleteItem(item.id)) {
                        showMessage("Item deleted.");
                        showInventoryScreen();
                    } else {
                        showMessage("Could not delete item.");
                    }
                })
                .show();
    }

    private void showItemDialog(InventoryItem existingItem) {
        View form = getLayoutInflater().inflate(R.layout.dialog_item, null);
        EditText name = form.findViewById(R.id.editItemName);
        EditText quantity = form.findViewById(R.id.editQuantity);
        EditText threshold = form.findViewById(R.id.editThreshold);

        if (existingItem != null) {
            name.setText(existingItem.name);
            quantity.setText(String.valueOf(existingItem.quantity));
            threshold.setText(String.valueOf(existingItem.threshold));
        } else {
            threshold.setText("0");
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existingItem == null ? "Add inventory item" : "Update inventory item")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(listener ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    String itemName = name.getText().toString().trim();

                    if (itemName.isEmpty()) {
                        name.setError("Enter an item name.");
                        return;
                    }

                    Integer itemQuantity = getNumber(quantity);
                    Integer itemThreshold = getNumber(threshold);

                    if (itemQuantity == null || itemThreshold == null) {
                        return;
                    }

                    long id = databaseHelper.saveItem(
                            existingItem == null ? -1 : existingItem.id,
                            itemName,
                            itemQuantity,
                            itemThreshold
                    );

                    if (id == -1) {
                        showMessage("Could not save item.");
                        return;
                    }

                    InventoryItem savedItem = new InventoryItem(id, itemName, itemQuantity, itemThreshold);
                    dialog.dismiss();
                    showInventoryScreen();
                    showMessage("Item saved.");

                    if (savedItem.isLow() && (existingItem == null || !existingItem.isLow())) {
                        sendLowInventoryAlert(savedItem);
                    }
                })
        );

        dialog.show();
    }

    private Integer getNumber(EditText field) {
        try {
            int value = Integer.parseInt(field.getText().toString().trim());
            if (value < 0) {
                field.setError("Enter 0 or a positive number.");
                return null;
            }
            return value;
        } catch (NumberFormatException e) {
            field.setError("Enter a whole number.");
            return null;
        }
    }

    private void showNotificationScreen() {
        if (!loggedIn) {
            showLoginScreen();
            return;
        }

        currentScreen = 2;
        setContentView(R.layout.activity_notifications);

        EditText phoneField = findViewById(R.id.editPhone);
        phoneField.setText(smsSettings.getString("phone", ""));

        updatePermissionStatus();

        findViewById(R.id.buttonAllowSms).setOnClickListener(v -> {
            String phone = phoneField.getText().toString().trim();

            if (phone.isEmpty()) {
                phoneField.setError("Enter a phone number.");
                return;
            }

            smsSettings.edit().putString("phone", phone).apply();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                smsSettings.edit().putBoolean("enabled", true).apply();
                showMessage("SMS alerts enabled.");
                updatePermissionStatus();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            }
        });

        findViewById(R.id.buttonDenySms).setOnClickListener(v -> {
            smsSettings.edit().putBoolean("enabled", false).apply();
            showMessage("SMS alerts disabled. Inventory will still work normally.");
            updatePermissionStatus();
        });

        findViewById(R.id.buttonBackInventory).setOnClickListener(v -> showInventoryScreen());
    }

    private void updatePermissionStatus() {
        TextView status = findViewById(R.id.textPermissionStatus);
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        boolean enabled = smsSettings.getBoolean("enabled", false) && permissionGranted;

        status.setText("Android permission: " + (permissionGranted ? "allowed" : "denied")
                + "\nApp alerts: " + (enabled ? "enabled" : "disabled"));
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            smsSettings.edit().putBoolean("enabled", granted).apply();

            if (granted) {
                showMessage("SMS alerts enabled.");
            } else {
                showMessage("SMS permission denied. Inventory will still work normally.");
            }

            updatePermissionStatus();
        }
    }

    @SuppressWarnings("deprecation")
    private void sendLowInventoryAlert(InventoryItem item) {
        boolean enabled = smsSettings.getBoolean("enabled", false);
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!enabled || !permissionGranted) {
            return;
        }

        String phone = smsSettings.getString("phone", "");
        if (phone.isEmpty()) {
            return;
        }

        String message = "Inventory alert: " + item.name
                + " has " + item.quantity + " remaining.";

        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            showMessage("Low inventory SMS alert sent.");
        } catch (Exception e) {
            showMessage("SMS could not be sent. Inventory was still saved.");
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        databaseHelper.close();
        super.onDestroy();
    }
}
