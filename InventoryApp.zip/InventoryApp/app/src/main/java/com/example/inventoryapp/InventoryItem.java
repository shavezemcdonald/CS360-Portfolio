package com.example.inventoryapp;

public class InventoryItem {
    public long id;
    public String name;
    public int quantity;
    public int threshold;

    public InventoryItem(long id, String name, int quantity, int threshold) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.threshold = threshold;
    }

    public boolean isLow() {
        return quantity <= threshold;
    }
}
