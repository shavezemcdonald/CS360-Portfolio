package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL, " +
                "threshold INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password", password);

        long result = getWritableDatabase().insert("users", null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"id"},
                "username = ? AND password = ?",
                new String[]{username.trim(), password},
                null,
                null,
                null
        );

        boolean found = cursor.moveToFirst();
        cursor.close();
        return found;
    }

    public List<InventoryItem> getItems() {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(
                "inventory",
                null,
                null,
                null,
                null,
                null,
                "name ASC"
        );

        while (cursor.moveToNext()) {
            items.add(new InventoryItem(
                    cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("threshold"))
            ));
        }

        cursor.close();
        return items;
    }

    public long saveItem(long id, String name, int quantity, int threshold) {
        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);
        values.put("threshold", threshold);

        if (id == -1) {
            return getWritableDatabase().insert("inventory", null, values);
        }

        int updated = getWritableDatabase().update(
                "inventory",
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return updated > 0 ? id : -1;
    }

    public boolean deleteItem(long id) {
        int deleted = getWritableDatabase().delete(
                "inventory",
                "id = ?",
                new String[]{String.valueOf(id)}
        );
        return deleted > 0;
    }
}
